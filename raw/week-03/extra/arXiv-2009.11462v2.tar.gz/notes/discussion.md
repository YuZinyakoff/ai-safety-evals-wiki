Disucssion outline

# tying together all our findings
We demonstrated that neural toxic generations happens in out of the box models, and steering methods highlighted the role of pretraining data.
Then we showed that popular language models are in fact pretrained on a variety of problematic documents, including unreliable news sources and content shared on hateful subreddits.


# Implications (unclear about ordering)
## Forgetting toxicity
An obvious question raised by our findings is, does the model ever "forget" bad data?
DAPT shows that maybe yes, but then again it still regurgitates bad stuff when prompted, so further experiments are needed to examine whether this is truly possible.

## Decoding with a purpose
Another implication is the promise of PPLM-style methods, which are nice cause not everyone can train a whole new system.
PPLM style methods are extremely expensive, so more work needs to be done to make them effective AND cheap to run
While PPLM still had issues for non-toxic prompts, (potentially cause classifier isn't aligned with toxicity?) ,
we could use more sophisticated inferences for decoding while avoiding harm to populations \cite{sap2020socialbiasframes}, etc.

## Pretraining data
 (basically what suchin wrote, possibly condensed :) )
we should pay attention to what models are exposed to 
- people should always release their data (to allow in-depth analyses)
- measuring what is ``bad'' is hard also has its own issues (echo bias in measurements stuff, summarize limitations of toxicity detection, social bias frames-style reasoning about implications of language)
- deciding what should and should be included is in itself a hard question (use participatory design to select pretrainign data)


## Limitations
- we use a flawed toxicity classifier
- we didn't look at more models (e.g., pretrained on other domains, MLMs)
- overlap problem limits findings on GPT2 training data
- overlap between reliability ratings and sources limit findings.

