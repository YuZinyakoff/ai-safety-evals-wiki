# Title
- Detoxifying Neural Language Generation with WildToxicityPrompts
- See No Evil, Hear No Evil, Speak No Evil [or some variant] 
- Detoxifying Transformer Language Model Generation
- Evaluating and Avoiding Toxicity in Neural Language Model Generations
- Language Models Out of Control
- Language Models Gone Awry
- RealToxicityPrompts: A New Test Bed for Testing and Controlling Neural Toxic Language
- RealToxicityPrompts: Evaluating Neural Toxic Language Degeneration
- RealToxicityPrompts: Evaluating Toxic Degeneration in Pretrained Language Models
- RealToxicityPrompts: Evaluating Neural Toxic Degeneration in Language Models


# Prompts Dataset Name
- RealToxicPrompts
- WildToxicityPrompts
- NaturalToxicPrompts
- NaturalAdversarialPrompts
- WebPrompts
- ToxicContexts
- BadAutocompletePrompts

# Affect
- Late fusion
- Sage
- Vocab Shift *

# CTRL
- Inline metadata
- Attribute-conditioned (ATCON) *
- Control

# Banned Word Filter
- Blocklist
- Banlist
